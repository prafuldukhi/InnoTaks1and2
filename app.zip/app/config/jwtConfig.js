
//Add your own custom secret jwt code or  key in production time 
module.exports = {
    jwtSecret: 'your_jwt_secret',
  };
  