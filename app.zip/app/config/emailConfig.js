
//Add Your Email Address Here 
module.exports = {
    emailUser: 'your_email_user',
    emailPass: 'your_email_password',
  };
  