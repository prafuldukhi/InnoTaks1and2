# tasks
 developing a Node.js API with endpoints for user authentication (login and  signup) and user with  profile management. and send email
