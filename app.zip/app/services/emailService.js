const nodemailer = require('nodemailer');
const { emailUser, emailPass } = require('../config/emailConfig');

const sendConfirmationEmail = (recipientEmail) => {
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: emailUser,
      pass: emailPass,
    },
  });

  const mailOptions = {
    from: emailUser,
    to: recipientEmail,
    subject: 'Confirmation Email',
    html: '<p>Please click <a href="http://localhost:3000/confirm">here</a> to confirm your email.</p>',
  };

  transporter.sendMail(mailOptions, (err, info) => {
    if (err) {
      console.error('Error sending email: ' + err.message);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
};

module.exports = { sendConfirmationEmail };